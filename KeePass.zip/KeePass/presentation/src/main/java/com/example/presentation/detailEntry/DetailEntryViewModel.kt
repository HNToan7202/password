package com.example.presentation.detailEntry

import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class DetailEntryViewModel @Inject constructor(): BaseViewModel() {
}