package com.example.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import app.keemobile.kotpass.models.Entry
import com.example.presentation.R
import com.example.presentation.nav.AppTopBar
import com.example.presentation.base.BaseScreen
import com.example.presentation.home.component.BottomSheetMenuItem
import com.example.presentation.home.component.MenuItem
import com.example.presentation.nav.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel,
) {
    val entries = viewModel.entries.collectAsState().value
    val showAddMenu = viewModel.showAddMenu.value
    val showSettingsMenu = viewModel.showSettingsMenu.value

    val showBottomSheet = viewModel.showBottomSheet.value

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val scope = rememberCoroutineScope()

    if (showBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = {
                viewModel.toggleBottomSheet(false)
            },
            sheetState = sheetState
        ) {
            // Nội dung của BottomSheet
            Column() {
                Text(
                    "Add new",
                    modifier = Modifier.padding(top = 16.dp, start = 16.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                val menuItems = listOf(
                    MenuItem("Password", Icons.Default.Lock),
                    MenuItem("Secure Note", Icons.Default.Lock),
                    MenuItem("Credit Card", Icons.Default.Lock),
                    MenuItem("Contact Info", Icons.Default.Lock),
                    MenuItem("Folder", Icons.Default.Lock),
                )

                LazyColumn {
                    items(menuItems.size) { i ->
                        BottomSheetMenuItem(menuItems[i]) {
                            viewModel.toggleBottomSheet(false)
                            navController.navigate(Screen.NewPasswordScreen.route)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    BaseScreen(
        uiState = viewModel.uiState.value,
        onErrorDismiss = {},
        onSuccessDismiss = {},
        content = {
            Scaffold(topBar = {
                AppTopBar("Manage Password", navController, actions = {
                    // Icon + Menu Add
                    Box {
                        IconButton(onClick = { viewModel.toggleBottomSheet(true) }) {
                            Icon(
                                painter = painterResource(R.drawable.outline_add_box_24),
                                contentDescription = "Add"
                            )
                        }
                        DropdownMenu(
                            expanded = showAddMenu,
                            onDismissRequest = { viewModel.onToggleAddMenu(false) }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Thêm mật khẩu") },
                                onClick = {
                                    viewModel.onToggleAddMenu(false)
                                }
                            )
                        }
                    }

                    // Icon + Menu Settings
                    Box {
                        IconButton(onClick = { viewModel.onToggleSettingsMenu(true) }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_setting),
                                contentDescription = "Settings"
                            )
                        }
                        DropdownMenu(
                            expanded = showSettingsMenu,
                            onDismissRequest = { viewModel.onToggleSettingsMenu(false) }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Cài đặt") },
                                onClick = {
                                    viewModel.onToggleSettingsMenu(false)
                                }
                            )
                        }
                    }
                })
            }) { paddingValue ->
                EntryListScreen(entries, navController, Modifier.padding(paddingValue))
            }
        }
    )
}

@Composable
fun EntryListScreen(entries: List<Entry>, navController: NavController, modifier: Modifier) {

    LazyColumn(modifier = modifier) {
        items(entries.size) { i ->
            EntryListItem(entry = entries[i], onItemClick = {
                navController.navigate(Screen.DetailEntryScreen.route)
            })
        }
    }
}

@Composable
fun EntryListItem(entry: Entry, onItemClick: (Entry) -> Unit) {
    Row(
        modifier = Modifier
            .clickable { onItemClick(entry) } // Make the entire row clickable
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Blue),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(R.drawable.key_icon),
                    contentDescription = "Entry Icon",
                    modifier = Modifier.size(24.dp), // Set the size of the icon
                    tint = Color.White // Set the icon color to white
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f) // Let this Column take up remaining space
            ) {
                Text(text = " ${entry.fields.userName?.content ?: "No Username"}")
                if (entry.fields.password != null) {
                    Text(text = "Password: ${entry.fields.password?.content ?: "No Password"}")
                }
            }

            // Next icon button
            IconButton(
                modifier = Modifier
                    .size(24.dp)
                    .clickable { }, // Handle click event for the Next icon
                onClick = { /* Handle click here, if needed */ }
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_chervon_right),
                    contentDescription = "Next",
                    tint = Color.Gray // Adjust the tint of the icon as needed
                )
            }
        }
    }
}