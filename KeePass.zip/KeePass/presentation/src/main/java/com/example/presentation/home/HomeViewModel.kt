package com.example.presentation.home

import androidx.compose.runtime.mutableStateOf
import app.keemobile.kotpass.models.Entry
import com.example.data.repository.keepass.KeepassDatabaseRepository
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import androidx.compose.runtime.State

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val keepassDatabaseRepository: KeepassDatabaseRepository
) : BaseViewModel() {

    private val _showBottomSheet = mutableStateOf(false)
    val showBottomSheet: State<Boolean> = _showBottomSheet

    fun toggleBottomSheet(show: Boolean) {
        _showBottomSheet.value = show
    }

    private val _entries = MutableStateFlow<List<Entry>>(emptyList())
    val entries: StateFlow<List<Entry>> = _entries

    init {
        _entries.value = loadEntries()
    }

    private fun loadEntries(): List<Entry> {
        return keepassDatabaseRepository.getAllEntries()
    }

    private val _showAddMenu = mutableStateOf(false)
    val showAddMenu: State<Boolean> = _showAddMenu

    private val _showSettingsMenu = mutableStateOf(false)
    val showSettingsMenu: State<Boolean> = _showSettingsMenu

    fun onToggleAddMenu(show: Boolean) {
        _showAddMenu.value = show
    }

    fun onToggleSettingsMenu(show: Boolean) {
        _showSettingsMenu.value = show
    }
}