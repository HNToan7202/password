package com.example.presentation.newdb

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.presentation.R
import com.example.presentation.nav.AppTopBar
import com.example.presentation.nav.Screen
import com.example.presentation.theme.Styles
import com.example.presentation.base.BaseScreen
import kotlinx.coroutines.delay


@Composable
fun NewDatabaseScreen(
    navController: NavController?, viewModel: NewDatabaseViewModel
) {

    val context = LocalContext.current
    val savedStateHandle = navController?.currentBackStackEntry?.savedStateHandle
    viewModel.updatePath(context)
    val scrollState = rememberScrollState()

    val localFocusManager = androidx.compose.ui.platform.LocalFocusManager.current


    LaunchedEffect(savedStateHandle) {
        viewModel.handleSavedState(savedStateHandle)
    }

    BaseScreen(
        uiState = viewModel.uiState.value,
        onSuccessDismiss = {
            viewModel.setIdle()
            navController?.navigate(Screen.HomeScreen.route) {
                popUpTo(Screen.NewDatabaseScreen.route) { inclusive = true }
            }
        },
        onErrorDismiss = {
            viewModel.setIdle()
        },
        content = {
            Scaffold(
                topBar = { AppTopBar("Create New Database", navController) }) { paddingValue ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValue)
                        .verticalScroll(scrollState)
                        .padding(16.dp)
                        .imePadding()
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) {
                            localFocusManager.clearFocus()
                        }
                ) {
                    Column {
                        Text(text = "Vị trí cơ sở dữ liệu", style = Styles.BodyMedium)

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .padding(top = 8.dp, start = 16.dp)
                                .fillMaxWidth()
                        ) {
                            Icon(
                                contentDescription = null,
                                painter = painterResource(R.drawable.ic_info_24)
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .fillMaxWidth()
                        ) {
                            Icon(
                                contentDescription = null,
                                painter = painterResource(R.drawable.ic_save),
                                modifier = Modifier
                                    .width(40.dp)
                                    .height(40.dp)
                            )

                            Text("Tập tin cục bộ", style = Styles.NormalText16)
                        }

                        Text(viewModel.storagePath, Modifier.padding(top = 8.dp))

//                        Button(
//                            modifier = Modifier.padding(top = 8.dp),
//                            onClick = {
//                                navController?.navigate(Screen.StorageListScreen.route)
//                            },
//                        ) {
//                            Text("Thay đổi vị trí")
//                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Mật mã chủ", style = Styles.BodyMedium)

                    Text(
                        "Chọn một mật mã chủ để bảo vệ cơ sở dữ liệu của bạn:",
                        modifier = Modifier.padding(start = 16.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // File Name input
                    OutlinedTextField(
                        value = viewModel.fileName,
                        onValueChange = { viewModel.updateFileName(it) },
                        label = { Text("File name") },
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            Text(".kdbx", style = MaterialTheme.typography.bodyMedium)
                        })

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = viewModel.password,
                        onValueChange = { viewModel.updatePassword(it) },
                        label = { Text("Password") },
                        visualTransformation = if (viewModel.isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { viewModel.togglePasswordVisibility() }) {
                                Icon(
                                    painter = painterResource(
                                        if (viewModel.isPasswordVisible) R.drawable.ic_eye_open else R.drawable.ic_eye_close
                                    ),
                                    contentDescription = if (viewModel.isPasswordVisible) "Hide password" else "Show password"
                                )
                            }
                        })

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = viewModel.confirmPassword,
                        onValueChange = { viewModel.updateConfirmPassword(it) },
                        label = { Text("Confirm") },
                        visualTransformation = if (viewModel.isConfirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { viewModel.toggleConfirmPasswordVisibility() }) {
                                Icon(
                                    painter = painterResource(
                                        if (viewModel.isConfirmPasswordVisible) R.drawable.ic_eye_open else R.drawable.ic_eye_close
                                    ),
                                    contentDescription = if (viewModel.isConfirmPasswordVisible) "Hide password" else "Show password"
                                )
                            }
                        })

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            if (viewModel.isFieldsValid()) {
                                viewModel.setLoading()
                                viewModel.createNewDatabaseFile()
                            } else {
                                Toast.makeText(
                                    context,
                                    "Vui lòng kiểm tra thông tin rồi thử lại",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }, modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Tạo cơ sở dữ liệu")
                    }
                }
            }
        })
}

@Preview
@Composable
fun NewDatabaseScreenPreview() {
    NewDatabaseScreen(navController = null, viewModel = hiltViewModel())
}