package com.example.presentation.newPassword

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class NewPasswordViewModel @Inject constructor() : BaseViewModel() {

    var title by mutableStateOf("")
    var userName by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmPassword by mutableStateOf("")

    var isPasswordVisible by mutableStateOf(false)
    var isConfirmPasswordVisible by mutableStateOf(false)


    fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
    }

    fun toggleConfirmPasswordVisibility() {
        isConfirmPasswordVisible = !isConfirmPasswordVisible
    }


    fun updateTitle(titleValue: String) {
        title = titleValue
    }

    fun updateUserName(userNameValue: String) {
        userName = userNameValue
    }

    fun updatePassword(passwordValue: String) {
        password = passwordValue
    }

    fun updateConfirmPassword(passwordValue: String) {
        confirmPassword = passwordValue
    }
}