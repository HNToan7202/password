package com.example.presentation.nav


sealed class Screen(val route: String) {
    object NewDatabaseScreen : Screen("NewDatabaseScreen")
    object StorageListScreen : Screen("StorageListScreen")
    object OpenAndNewScreen : Screen("OpenAndNewScreen")
    object HomeScreen : Screen("HomeScreen")
    object OpenDatabaseScreen : Screen("OpenDatabaseScreen")
    object DetailEntryScreen : Screen("DetailEntryScreen")
    object NewPasswordScreen : Screen("NewPasswordScreen")
}

