package com.example.presentation.newPassword

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.presentation.R
import com.example.presentation.base.BaseScreen
import com.example.presentation.nav.AppTopBar

@Composable
fun NewPasswordScreen(navController: NavController, viewModel: NewPasswordViewModel) {
    BaseScreen(uiState = viewModel.uiState.value, content = {
        Scaffold(
            topBar = {
                AppTopBar("New Entry", navController, actions = {
                    IconButton(onClick = {}) {
                        Icon(
                            contentDescription = null,
                            painter = painterResource(R.drawable.outline_add_box_24)
                        )
                    }
                })
            },
        ) { paddingValue ->
            Column(modifier = Modifier
                .padding(paddingValue)
                .padding(16.dp)) {

                OutlinedTextField(
                    value = viewModel.title,
                    onValueChange = { viewModel.updateTitle(it) },
                    label = { Text("Title") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                    })

                OutlinedTextField(
                    value = viewModel.title,
                    onValueChange = { viewModel.updateTitle(it) },
                    label = { Text("Username") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                    })

                OutlinedTextField(
                    value = viewModel.password,
                    onValueChange = { viewModel.updatePassword(it) },
                    label = { Text("Password") },
                    visualTransformation = if (viewModel.isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { viewModel.togglePasswordVisibility() }) {
                            Icon(
                                painter = painterResource(
                                    if (viewModel.isPasswordVisible) R.drawable.ic_eye_open else R.drawable.ic_eye_close
                                ),
                                contentDescription = if (viewModel.isPasswordVisible) "Hide password" else "Show password"
                            )
                        }
                    })

                OutlinedTextField(
                    value = viewModel.confirmPassword,
                    onValueChange = { viewModel.updateConfirmPassword(it) },
                    label = { Text("Confirm") },
                    visualTransformation = if (viewModel.isConfirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { viewModel.toggleConfirmPasswordVisibility() }) {
                            Icon(
                                painter = painterResource(
                                    if (viewModel.isConfirmPasswordVisible) R.drawable.ic_eye_open else R.drawable.ic_eye_close
                                ),
                                contentDescription = if (viewModel.isConfirmPasswordVisible) "Hide password" else "Show password"
                            )
                        }
                    })

                OutlinedTextField(
                    value = viewModel.title,
                    onValueChange = { viewModel.updateTitle(it) },
                    label = { Text("URL") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                    })


                OutlinedTextField(
                    value = viewModel.title,
                    onValueChange = { viewModel.updateTitle(it) },
                    label = { Text("Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                    })
            }

        }
    })

}