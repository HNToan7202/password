package com.example.data.repository.keepass

import android.content.Context
import app.keemobile.kotpass.constants.BasicField
import app.keemobile.kotpass.database.Credentials
import app.keemobile.kotpass.database.KeePassDatabase
import app.keemobile.kotpass.database.encode
import app.keemobile.kotpass.database.modifiers.modifyMeta
import app.keemobile.kotpass.models.Entry
import app.keemobile.kotpass.models.EntryFields
import app.keemobile.kotpass.models.EntryValue
import app.keemobile.kotpass.models.Meta
import com.example.data.entity.FSAuthority.Companion.INTERNAL_FS_AUTHORITY
import com.example.data.entity.FileDescriptor
import com.example.data.extension.mapError
import com.example.data.file.FSOptions
import com.example.data.file.FileSystemResolver
import com.example.data.file.OnConflictStrategy
import com.example.data.file.Regular.RegularFileSystemProvider
import com.example.data.repository.ancdb.EncryptedDatabaseKey
import com.example.data.result.OperationError.MESSAGE_WRITE_OPERATION_IS_NOT_SUPPORTED
import com.example.data.result.OperationError.newGenericIOError
import com.example.data.result.OperationResult
import com.example.data.result.Stacktrace
import timber.log.Timber
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.withLock

class KotpassDatabase(
    private val context: Context,
    private val fsResolver: FileSystemResolver,
    private val fsOptions: FSOptions,
    file: FileDescriptor,
    key: EncryptedDatabaseKey,
    db: KeePassDatabase
) {

    private val database = AtomicReference(db)

    companion object {

        const val DEFAULT_ROOT_INHERITABLE_VALUE = true

        private const val DEFAULT_ROOT_GROUP_NAME = "Database"

        fun new(
            context: Context,
            credentials: Credentials,
            fsOptions: FSOptions,
            file: FileDescriptor,
        ): OperationResult<KeePassDatabase> {


            val rawDb = KeePassDatabase.Ver4x.create(
                rootName = DEFAULT_ROOT_GROUP_NAME,
                meta = Meta(
                    recycleBinEnabled = true
                ),
                credentials = credentials
            )

            val newEntry = Entry(
                uuid = UUID.randomUUID(),
                overrideUrl = "12345",
                fields = EntryFields.of(
                    BasicField.Title() to EntryValue.Plain("This is default entry"),
                    BasicField.Password() to EntryValue.Plain("default password entry"),
                    BasicField.UserName() to EntryValue.Plain("default username entry"),
                )
            )

            val oldGroup = rawDb.content.group
            val updatedGroup = oldGroup.copy(entries = oldGroup.entries + newEntry)

            val updatedDb = rawDb.copy(content = rawDb.content.copy(group = updatedGroup))

//            val fsOptions = FSOptions.DEFAULT

            val finalDb = updatedDb.modifyMeta {
                copy(
                    recycleBinEnabled = true,
                    recycleBinUuid = UUID.randomUUID(),
                    entryTemplatesGroup = entryTemplatesGroup
                )
            }

            val database = AtomicReference(finalDb)

            val updatedFile = file.copy(modified = System.currentTimeMillis())

            val fsProvider = RegularFileSystemProvider(context, INTERNAL_FS_AUTHORITY)

            val outResult = fsProvider.openFileForWrite(
                updatedFile,
                OnConflictStrategy.CANCEL,
                fsOptions
            )

            if (outResult.isFailed) {
                Timber.e("Kotpass: Failed to open file: ${outResult.error?.message}")

                return OperationResult.error(
                    newGenericIOError(
                        MESSAGE_WRITE_OPERATION_IS_NOT_SUPPORTED,
                        Stacktrace()
                    )
                )
            }

            val out = outResult.obj!!
            database.get().encode(out)
            Timber.d("Kotpass: Database written successfully: ${updatedFile.path}")

            return OperationResult.success(finalDb)

        }

    }

}