package com.example.data.result

class Stacktrace : Exception()