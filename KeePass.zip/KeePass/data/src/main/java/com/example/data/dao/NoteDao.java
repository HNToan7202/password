package com.example.data.dao;

import androidx.annotation.NonNull;

import com.example.data.entity.Note;

public interface NoteDao {

//    @NonNull
//    OperationResult<List<Note>> getAll();
//
//    @NonNull
//    OperationResult<List<Note>> getNotesByGroupUid(@NonNull UUID groupUid);
//
//    @NonNull
//    OperationResult<Note> getNoteByUid(@NonNull UUID noteUid);

//    @NonNull
//    OperationResult<UUID> insert(@NonNull Note note);
//
//    @NonNull
//    OperationResult<Boolean> insert(@NonNull List<Note> notes);
//
//    // TODO: this method is used only by TemplateDaoImpl
//    @NonNull
//    OperationResult<Boolean> insert(@NonNull List<Note> notes, boolean doCommit);

//    @NonNull
//    OperationResult<UUID> update(@NonNull Note note, boolean doCommit);

//    @NonNull
//    OperationResult<Boolean> remove(@NonNull UUID noteUid);

//    @NonNull
//    OperationResult<List<Note>> find(@NonNull String query);

//    @NonNull
//    ContentWatcher<Note> getContentWatcher();
//
//    @NonNull
//    OperationResult<List<Note>> getHistory(@NonNull UUID noteUid);
}
