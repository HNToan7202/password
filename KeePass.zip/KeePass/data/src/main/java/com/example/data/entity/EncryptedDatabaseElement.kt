package com.example.data.entity

/**
 * Interface for [Group], [Note] and [Property]
 */
interface EncryptedDatabaseElement