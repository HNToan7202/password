package com.example.data.entity

import java.util.UUID

data class GroupEntity(
    val uid: UUID? = null,
    val parentUid: UUID? = null,
    val title: String,
    val autotypeEnabled: InheritableBooleanOption,
    val searchEnabled: InheritableBooleanOption
)