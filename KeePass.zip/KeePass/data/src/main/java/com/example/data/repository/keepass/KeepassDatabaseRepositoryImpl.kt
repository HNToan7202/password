package com.example.data.repository.keepass

import android.content.Context
import app.keemobile.kotpass.database.Credentials
import app.keemobile.kotpass.database.KeePassDatabase
import app.keemobile.kotpass.models.Entry
import com.example.data.entity.FileDescriptor
import com.example.data.file.FSOptions
import com.example.data.repository.ancdb.EncryptedDatabaseKey
import com.example.data.result.OperationResult
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.atomic.AtomicReference
import javax.inject.Inject

class KeepassDatabaseRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : KeepassDatabaseRepository {

    private var database: AtomicReference<KeePassDatabase?>? = null

    override suspend fun createNewDatabase(
        credentials: Credentials,
        fsOptions: FSOptions,
        file: FileDescriptor,
    ): OperationResult<KeePassDatabase> {
        return KotpassDatabase.new(context, credentials, fsOptions, file)
    }

    override fun setDatabase(db: KeePassDatabase) {
        database = AtomicReference(db)
    }

    override fun getDatabase(): KeePassDatabase? = database?.get()

    override fun getAllEntries(): List<Entry> {
        return database?.get()?.content?.group?.entries ?: emptyList()
    }

    override fun isOpened(): Boolean = (database?.get() != null)

    private data class DatabaseReference(
        val type: KeepassImplementation,
        var database: KeePassDatabase
    )

}