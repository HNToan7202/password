package com.example.domain

import android.content.Context
import javax.inject.Inject

class FileHelper @Inject constructor(
    private val context: Context
) {

}