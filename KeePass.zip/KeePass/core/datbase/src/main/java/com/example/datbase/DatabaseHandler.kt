package com.example.datbase

import android.content.Context
import org.linguafranca.pwdb.kdbx.KdbxCreds
import org.linguafranca.pwdb.kdbx.jackson.JacksonDatabase
import org.linguafranca.pwdb.kdbx.jackson.JacksonEntry
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

class DatabaseHandler {

    @Throws(java.lang.Exception::class)
    fun createDatabase(context: Context, masterPassword: String): JacksonDatabase {

        val creds = KdbxCreds(masterPassword.toByteArray());
        val database = JacksonDatabase()
        dat
        val outputFile = File(context.filesDir, "test.kdbx")
        database.save(creds, FileOutputStream(outputFile))
        return database;
    }

    @Throws(java.lang.Exception::class)
    fun openDatabase(context: Context, masterPassword: String): JacksonDatabase {
        val file = File(context.filesDir, "test1.kdbx")
        val inputStream: InputStream = FileInputStream(file)
        val creds: KdbxCreds = KdbxCreds(masterPassword.toByteArray())
        var jacksonDatabase = JacksonDatabase.load(creds, inputStream)
        return jacksonDatabase
    }


    fun addEntryToRootGroup(
        context: Context,
        database: JacksonDatabase,
        title: String?,
        username: String?,
        password: String?,
        url: String?,
        masterPassword: String,
        keyFileStream: InputStream?
    ) {
        try {
            // Lấy nhóm gốc
            val rootGroup = database.rootGroup
            // Tạo mục nhập mới
            val newEntry = database.newEntry()
            newEntry.setTitle(title)
            newEntry.setUsername(username)
            newEntry.setPassword(password)
            newEntry.setUrl(url)
            rootGroup.addEntry(newEntry)
            val outputFile = File(context.filesDir, "output.kdbx")

            val creds = if (keyFileStream != null) KdbxCreds(
                masterPassword.toByteArray(),
                keyFileStream
            ) else KdbxCreds(masterPassword.toByteArray())
            database.save(creds, FileOutputStream(outputFile))
        } catch (e: Exception) {

        }

    }

    fun addEntryToNewGroup(
        context: Context,
        database: JacksonDatabase,
        masterPassword: String,
        newGroupName: String,
        entry: JacksonEntry,
        keyFileStream: InputStream?
    ) {
        val newGroup = database.newGroup()
        newGroup.name = newGroupName
        newGroup.addEntry(entry)
        val outputFile = File(context.filesDir, "output.kdbx")
        val creds = if (keyFileStream != null) KdbxCreds(
            masterPassword.toByteArray(),
            keyFileStream
        ) else KdbxCreds(masterPassword.toByteArray())
        database.save(creds, FileOutputStream(outputFile))
    }

}