package com.example.presentation.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.presentation.detailEntry.DetailEntryScreen
import com.example.presentation.openandnew.OpenAndNewScreen
import com.example.presentation.newdb.NewDatabaseScreen
import com.example.presentation.openDatabase.OpenDatabaseScreen
import com.example.presentation.storage.SelectStorageScreen
import com.example.presentation.home.HomeScreen
import com.example.presentation.newPassword.NewPasswordScreen

@Composable
fun Navigation() {
    val navController = rememberNavController()
    val context = LocalContext.current

    NavHost(navController = navController, startDestination = Screen.OpenAndNewScreen.route) {

        composable(Screen.OpenAndNewScreen.route) {
            OpenAndNewScreen(
                navController = navController,
                viewModel = hiltViewModel(),
            )
        }

        composable(Screen.NewDatabaseScreen.route) {
            NewDatabaseScreen(
                navController = navController,
                viewModel = hiltViewModel(),
            )
        }

        composable(Screen.StorageListScreen.route) {
            SelectStorageScreen(
                navController = navController,
                viewModel = hiltViewModel(),
            )
        }
        composable(Screen.HomeScreen.route) {
            HomeScreen(
                navController = navController,
                viewModel = hiltViewModel(),
            )
        }

        composable(Screen.OpenDatabaseScreen.route) { backEntry ->

            val parentEntry = remember(backEntry) {
                navController.getBackStackEntry(Screen.StorageListScreen.route)
            }

            OpenDatabaseScreen(
                navController = navController,
                viewModel = hiltViewModel(),
                parentEntry = parentEntry
            )
        }

        composable(
            Screen.DetailEntryScreen.route + "/{uid}",
            arguments = listOf(navArgument("uid") {
                type =
                    NavType.StringType
            })
        ) { backEntry ->
            DetailEntryScreen(
                navController = navController,
                viewModel = hiltViewModel(),
            )
        }

        composable(Screen.NewPasswordScreen.route) { backEntry ->
            NewPasswordScreen(
                navController = navController,
                viewModel = hiltViewModel(),
            )
        }
    }
}