package com.example.presentation.storage

import android.os.Parcelable
import com.example.yourpass.presentation.storage.Action
import kotlinx.parcelize.Parcelize

@Parcelize
data class StorageListArgs(
    val action: Action,
    val resultKey: String
) : Parcelable