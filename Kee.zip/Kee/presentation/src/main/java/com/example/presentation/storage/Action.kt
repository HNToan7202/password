package com.example.yourpass.presentation.storage

enum class Action {
    PICK_FILE,
    PICK_STORAGE
}