package com.example.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import app.keemobile.kotpass.models.Entry
import com.example.presentation.R
import com.example.presentation.nav.AppTopBar
import com.example.presentation.base.BaseScreen
import com.example.presentation.home.component.BottomSheetMenuItem
import com.example.presentation.home.component.EntryListScreen
import com.example.presentation.home.component.MenuItem
import com.example.presentation.nav.Screen
import com.example.presentation.theme.Styles

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel,
) {
    val entries = viewModel.entries.collectAsState().value
    val showSettingsMenu = viewModel.showSettingsMenu.value

    val showBottomSheet = viewModel.showBottomSheet.value

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)


    val currentBackStackEntry = navController.currentBackStackEntryAsState().value

    LaunchedEffect(currentBackStackEntry) {
        if (currentBackStackEntry?.destination?.route == Screen.HomeScreen.route) {
            viewModel.updateEntries()
        }
    }

    if (showBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = {
                viewModel.toggleBottomSheet(false)
            },
            sheetState = sheetState
        ) {
            Column() {
                Text(
                    "Add new",
                    style = Styles.BodyMediumBold,
                    modifier = Modifier.padding(top = 16.dp, start = 16.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                val menuItems = listOf(
                    MenuItem("Password", painterResource(R.drawable.ic_password_out_line)),
                    MenuItem("Secure Note", painterResource(R.drawable.ic_sticky_note)),
                    MenuItem("Credit Card", painterResource(R.drawable.ic_credit_card)),
                    MenuItem("Folder", painterResource(R.drawable.new_folder)),
                )

                LazyColumn {
                    items(menuItems.size) { i ->
                        BottomSheetMenuItem(menuItems[i]) {
                            viewModel.toggleBottomSheet(false)
                            navController.navigate(Screen.NewPasswordScreen.route)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    BaseScreen(
        uiState = viewModel.uiState.value,
        onErrorDismiss = {},
        onSuccessDismiss = {},
        content = {
            Scaffold(topBar = {
                AppTopBar("Manage Password", navController, actions = {
                    Box {
                        IconButton(onClick = { viewModel.toggleBottomSheet(true) }) {
                            Icon(
                                painter = painterResource(R.drawable.outline_add_box_24),
                                contentDescription = "Add"
                            )
                        }
                    }

                    Box {
                        IconButton(onClick = { viewModel.onToggleSettingsMenu(true) }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_setting),
                                contentDescription = "Settings"
                            )
                        }
                        DropdownMenu(
                            expanded = showSettingsMenu,
                            onDismissRequest = { viewModel.onToggleSettingsMenu(false) }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Cài đặt") },
                                onClick = {
                                    viewModel.onToggleSettingsMenu(false)
                                }
                            )
                        }
                    }
                })
            }) { paddingValue ->
                EntryListScreen(
                    entries,
                    navController,
                    Modifier.padding(paddingValue),
                    onItemLongClick = {}, viewModel = viewModel
                )
            }
        }
    )
}
