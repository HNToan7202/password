package com.example.presentation.home.component

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.keemobile.kotpass.models.Entry
import com.example.presentation.R
import com.example.presentation.home.HomeViewModel
import com.example.presentation.nav.Screen

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EntryListItem(
    entry: Entry,
    onItemClick: (Entry) -> Unit,
    onItemLongClick: (Entry) -> Unit,
    viewModel: HomeViewModel
) {
    val showMenu =
        remember { mutableStateOf(false) } // State để kiểm tra nếu menu hiển thị hay không

    Row(
        modifier = Modifier
            .clickable { onItemClick(entry) } // Make the entire row clickable
            .combinedClickable(
                onClick = { onItemClick(entry) },
                onLongClick = {
                    onItemLongClick(entry)
                    showMenu.value = true // Hiển thị menu khi long click
                }
            )
    ) {
        Row(
            modifier = Modifier.padding(all = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(size = 40.dp)
                    .clip(CircleShape)
                    .background(Color.Blue),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(R.drawable.key_icon),
                    contentDescription = "Entry Icon",
                    modifier = Modifier.size(24.dp), // Set the size of the icon
                    tint = Color.White // Set the icon color to white
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(text = " ${entry.fields.userName?.content ?: "No Username"}")
                if (entry.fields.password != null) {
                    Text(text = "Password: ${entry.fields.password?.content ?: "No Password"}")
                }
            }

            // Next icon button
            IconButton(
                modifier = Modifier
                    .size(24.dp)
                    .clickable { }, // Handle click event for the Next icon
                onClick = { /* Handle click here, if needed */ }
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_chervon_right),
                    contentDescription = "Next",
                    tint = Color.Gray // Adjust the tint of the icon as needed
                )
            }

            // Dropdown menu
            DropdownMenu(
                expanded = showMenu.value,
                onDismissRequest = { showMenu.value = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Sửa") },
                    onClick = {
                        showMenu.value = false
                        // Xử lý chỉnh sửa mục (ví dụ: chuyển đến màn hình chỉnh sửa)
//                        navController.navigate("${Screen.EditEntryScreen.route}/${entry.uuid}")
                    }
                )
                DropdownMenuItem(
                    text = { Text("Xóa") },
                    onClick = {
                        showMenu.value = false
                        // Xử lý xóa mục
                        viewModel.deleteEntry(entry.uuid)
                    }
                )
            }
        }
    }
}