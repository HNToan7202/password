package com.example.presentation.home

import androidx.compose.runtime.mutableStateOf
import app.keemobile.kotpass.models.Entry
import com.example.data.repository.keepass.KeepassDatabaseRepository
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import androidx.compose.runtime.State
import androidx.lifecycle.viewModelScope
import app.keemobile.kotpass.models.Group
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.LinkedList
import java.util.UUID
import app.keemobile.kotpass.models.Group as RawGroup

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val keepassDatabaseRepository: KeepassDatabaseRepository
) : BaseViewModel() {

    private val _showBottomSheet = mutableStateOf(false)
    val showBottomSheet: State<Boolean> = _showBottomSheet
    private val _showSettingsMenu = mutableStateOf(false)
    val showSettingsMenu: State<Boolean> = _showSettingsMenu

    fun toggleBottomSheet(show: Boolean) {
        _showBottomSheet.value = show
    }

    private val _entries = MutableStateFlow<List<Entry>>(emptyList())
    val entries: StateFlow<List<Entry>> = _entries

    init {
        _entries.value = loadEntries()
    }

    fun loadEntries(): List<Entry> {
        return keepassDatabaseRepository.getAllEntries()
    }

    fun updateEntries() {
        viewModelScope.launch(Dispatchers.IO) {
            _entries.emit(keepassDatabaseRepository.getAllEntries())
        }
    }

    fun onToggleSettingsMenu(show: Boolean) {
        _showSettingsMenu.value = show
    }

    fun getRootGroupUid(): UUID? {
        return keepassDatabaseRepository.getRootGroupId()
    }

    fun getRawChildGroups(root: RawGroup): List<RawGroup> {
        val nextGroups = LinkedList<RawGroup>()
            .apply {
                add(root)
            }

        val allGroups = mutableListOf<RawGroup>()

        while (nextGroups.size > 0) {
            val currentGroup = nextGroups.removeFirst()

            nextGroups.addAll(currentGroup.groups)
            allGroups.addAll(currentGroup.groups)
        }

        return allGroups
    }

    fun deleteEntry(entryId: UUID) {
        viewModelScope.launch(Dispatchers.IO) {
            setLoading()
            keepassDatabaseRepository.removeEntry(entryId)
            updateEntries()
            setIdle()
        }

    }

}