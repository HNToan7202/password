package com.example.presentation.openandnew

import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import app.keemobile.kotpass.cryptography.EncryptedValue
import app.keemobile.kotpass.database.Credentials
import app.keemobile.kotpass.database.KeePassDatabase
import app.keemobile.kotpass.database.decode
import com.example.presentation.R
import com.example.presentation.nav.Screen
import com.example.presentation.theme.Dimens
import com.example.presentation.theme.Styles
import com.example.presentation.base.BaseScreen

@Composable
fun OpenAndNewScreen(
    navController: NavController?, viewModel: OpenAndNewViewModel
) {

    val context = LocalContext.current
    val savedStateHandle = navController?.currentBackStackEntry?.savedStateHandle
    val openFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->

        if (uri == null) {
            // Người dùng đã back hoặc không chọn file
            viewModel.setError("Bạn chưa chọn tệp nào.")
            return@rememberLauncherForActivityResult
        }

        uri.let {
            val credentials = Credentials.from(EncryptedValue.fromString("123"))
            val database = context.contentResolver.openInputStream(it)?.use { inputStream ->
                KeePassDatabase.decode(inputStream, credentials)
            }

            if (database != null) {
                viewModel.setSuccess()
            } else {
                viewModel.setError("Lỗi khi mở database")
            }

            Log.d("keepass", "${database?.content?.group?.name}")
        }
    }



    BaseScreen(
        uiState = viewModel.uiState.value,
        onErrorDismiss = {
            viewModel.setIdle()
        },
        onSuccessDismiss = {
            viewModel.setIdle()
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(Dimens.PaddingLarge),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Image(
                    painter = painterResource(R.drawable.password_manager),
                    modifier = Modifier
                        .padding(top = 70.dp)
                        .width(120.dp)
                        .height(120.dp),
                    contentDescription = null
                )

                Text(
                    modifier = Modifier.padding(top = 70.dp),
                    text = "YourPassword",
                    style = Styles.Heading
                )

                Button(
                    onClick = { navController?.navigate(Screen.NewDatabaseScreen.route) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = Dimens.PaddingLarge)
                ) {
                    Text("Create New Database")
                }

                Button(
                    onClick = {
//                        viewModel.setLoading()
//                        openFileLauncher.launch(arrayOf("*/*"))
                        navController?.navigate(Screen.StorageListScreen.route)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = Dimens.PaddingLarge)
                ) {
                    Text("Open Database")
                }

                Text(
                    "Open Recent", modifier = Modifier
                        .padding(top = 16.dp)
                        .fillMaxWidth()
                )

                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    thickness = 1.dp,
                    color = Color.Gray
                )

                LazyColumn {

                }
            }
        }
    )
}

@Composable
@Preview(showSystemUi = true)
fun OpenAndNewScreenPreview() {
    OpenAndNewScreen(
        navController = null,
        viewModel = hiltViewModel()
    )
}
