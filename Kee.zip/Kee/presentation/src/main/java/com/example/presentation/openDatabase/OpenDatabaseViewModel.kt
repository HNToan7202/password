package com.example.presentation.openDatabase

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewModelScope
import app.keemobile.kotpass.cryptography.EncryptedValue
import app.keemobile.kotpass.database.Credentials
import app.keemobile.kotpass.database.KeePassDatabase
import app.keemobile.kotpass.database.decode
import com.example.data.entity.FSAuthority.Companion.INTERNAL_FS_AUTHORITY
import com.example.data.entity.FileDescriptor
import com.example.data.file.FSOptions
import com.example.data.repository.keepass.KeepassDatabaseRepository
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class OpenDatabaseViewModel @Inject constructor(
    private val keepassDatabaseRepository: KeepassDatabaseRepository
) : BaseViewModel() {

    var password by mutableStateOf<String>("")

    var isPasswordVisible by mutableStateOf(false)


    fun updatePassword(passwordValue: String) {
        password = passwordValue
    }


    fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
    }


    fun openDatabase(file: File) {

        viewModelScope.launch(Dispatchers.IO) {
            setLoading()
            try {
                val credentials = Credentials.from(EncryptedValue.fromString(password))

                val database =
                    file.inputStream().use {
                        KeePassDatabase.decode(it, credentials)
                    }

                keepassDatabaseRepository.setDatabase(
                    db = database,
                    fsOptions = FSOptions.DEFAULT,
                    dbFile = file.toFileDescriptor()
                )
                setSuccess()
            } catch (e: Exception) {
                setError("Lỗi khi mở cơ sở dữ liệu: ${e.message}")
            }
        }
    }

    private fun File.toFileDescriptor(): FileDescriptor {
        return FileDescriptor(
            fsAuthority = INTERNAL_FS_AUTHORITY,
            path = path,
            uid = path,
            name = name,
            isDirectory = isDirectory,
            isRoot = true,
            modified = lastModified()
        )
    }


}