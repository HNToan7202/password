package com.example.presentation.newPassword

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewModelScope
import app.keemobile.kotpass.constants.BasicField
import app.keemobile.kotpass.models.Entry
import app.keemobile.kotpass.models.EntryFields
import app.keemobile.kotpass.models.EntryValue
import com.example.data.repository.keepass.KeepassDatabaseRepository
import com.example.yourpass.presentation.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class NewPasswordViewModel @Inject constructor(
    private val keepassDatabaseRepository: KeepassDatabaseRepository
) : BaseViewModel() {

    var title by mutableStateOf("")
    var url by mutableStateOf("")
    var note by mutableStateOf("")
    var userName by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmPassword by mutableStateOf("")

    var isPasswordVisible by mutableStateOf(false)
    var isConfirmPasswordVisible by mutableStateOf(false)

    fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
    }

    fun toggleConfirmPasswordVisibility() {
        isConfirmPasswordVisible = !isConfirmPasswordVisible
    }


    fun updateTitle(titleValue: String) {
        title = titleValue
    }


    fun updateNote(noteValue: String) {
        note = noteValue
    }

    fun updateURL(urlValue: String) {
        url = urlValue
    }

    fun updateUserName(userNameValue: String) {
        userName = userNameValue
    }

    fun updatePassword(passwordValue: String) {
        password = passwordValue
    }

    fun updateConfirmPassword(passwordValue: String) {
        confirmPassword = passwordValue
    }

    fun submit() {
        viewModelScope.launch(Dispatchers.IO) {
            setLoading()
            val entry = Entry(
                uuid = UUID.randomUUID(),
                previousParentGroup = keepassDatabaseRepository.getRootGroupId(),
                fields = EntryFields.of(
                    BasicField.Title() to EntryValue.Plain(title),
                    BasicField.Password() to EntryValue.Plain(password),
                    BasicField.UserName() to EntryValue.Plain(userName),
                ),
            )

            val result = keepassDatabaseRepository.addEntryToGroup(entry)

            if (result.isSucceeded) {
                setSuccess()
            } else {
                setError("Error to add entry")
            }
        }

    }
}