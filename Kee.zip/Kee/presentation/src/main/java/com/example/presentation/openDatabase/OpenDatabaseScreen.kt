package com.example.presentation.openDatabase

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import com.example.extension.R
import com.example.presentation.nav.AppTopBar
import com.example.presentation.nav.Screen
import com.example.presentation.storage.SelectStorageViewModel
import com.example.presentation.base.BaseScreen


@Composable
fun OpenDatabaseScreen(
    navController: NavController?,
    viewModel: OpenDatabaseViewModel,
    parentEntry: NavBackStackEntry
) {
    val storageViewModel: SelectStorageViewModel = hiltViewModel(parentEntry)
    val selectedFile = storageViewModel.selectedFile.value

    BaseScreen(
        uiState = viewModel.uiState.value,
        onErrorDismiss = {
            viewModel.setIdle()
        },
        onSuccessDismiss = {
            viewModel.setIdle()
            navController?.navigate(Screen.HomeScreen.route) {
                popUpTo(Screen.OpenDatabaseScreen.route) { inclusive = true }
            }
        },
        content = {
            if (selectedFile != null) {
                Scaffold(topBar = {
                    AppTopBar("OpenDatase", navController)
                }) { padding ->
                    Column(
                        modifier = Modifier
                            .padding(padding)
                            .padding(16.dp)
                    ) {
                        Text("Mở khóa cơ sở dữ liệu: ${selectedFile.name}")
                        Box(Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            OutlinedTextField(
                                value = viewModel.password,
                                onValueChange = { viewModel.updatePassword(it) },
                                label = { Text("Nhập mật khẩu") },
                                singleLine = true,
                                visualTransformation = if (viewModel.isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { viewModel.togglePasswordVisibility() }) {
                                        Icon(
                                            painter = painterResource(
                                                if (viewModel.isPasswordVisible)
                                                    com.example.presentation.R.drawable.ic_eye_open
                                                else
                                                    com.example.presentation.R.drawable.ic_eye_close
                                            ),
                                            contentDescription = if (viewModel.isPasswordVisible) "Ẩn mật khẩu" else "Hiện mật khẩu"
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 8.dp, top = 0.dp)
                            )

                            Button(
                                onClick = {
                                    try {
                                        viewModel.openDatabase(selectedFile)
                                    } catch (_: Exception) {
                                        viewModel.setError("Lỗi khi mở cơ sở dữ liệu")
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .height(62.dp)
                                    .padding(top = 6.dp)
                            ) {
                                Text("Mở khóa")
                            }
                        }
                    }

                }
            } else {
                viewModel.setError()
            }
        })

}