package com.example.data.repository.keepass

import app.keemobile.kotpass.database.Credentials
import app.keemobile.kotpass.database.KeePassDatabase
import app.keemobile.kotpass.models.Entry
import com.example.data.entity.FileDescriptor
import com.example.data.file.FSOptions
import com.example.data.repository.ancdb.EncryptedDatabaseKey
import com.example.data.result.OperationResult
import kotlinx.coroutines.flow.Flow
import java.util.UUID

interface KeepassDatabaseRepository {

    suspend fun createNewDatabase(
        credentials: Credentials,
        fsOptions: FSOptions,
        file: FileDescriptor,
    ): OperationResult<KeePassDatabase>


    fun setDatabase(db: KeePassDatabase, fsOptions: FSOptions, dbFile: FileDescriptor)
    fun getDatabase(): KeePassDatabase?
    fun getAllEntries(): List<Entry>
    fun isOpened(): Boolean
    fun getRootEntryById(id: UUID): Flow<Entry?>
    fun getRootGroupId(): UUID?
    suspend fun addEntryToGroup(entry: Entry): OperationResult<UUID?>
    fun removeEntry(entryId: UUID): OperationResult<Boolean>
}