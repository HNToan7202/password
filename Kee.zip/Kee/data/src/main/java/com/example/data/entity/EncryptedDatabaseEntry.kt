package com.example.data.entity

/**
 * Interface for [Group] and [Note]
 */
interface EncryptedDatabaseEntry : EncryptedDatabaseElement