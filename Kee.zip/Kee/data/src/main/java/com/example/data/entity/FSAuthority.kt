package com.example.data.entity

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class FSAuthority(
    val type: FSType,
    val isBrowsable: Boolean
) : Parcelable {

    companion object {
        val INTERNAL_FS_AUTHORITY = FSAuthority(
            type = FSType.INTERNAL_STORAGE,
            isBrowsable = true
        )

        val EXTERNAL_FS_AUTHORITY = FSAuthority(
            type = FSType.EXTERNAL_STORAGE,
            isBrowsable = true
        )

        val SAF_FS_AUTHORITY = FSAuthority(
            type = FSType.SAF,
            isBrowsable = false
        )
    }
}