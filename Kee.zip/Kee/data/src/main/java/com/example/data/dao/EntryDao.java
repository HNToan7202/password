package com.example.data.dao;

import androidx.annotation.NonNull;

import com.example.data.entity.Note;
import com.example.data.result.OperationResult;

import java.util.UUID;

import app.keemobile.kotpass.models.Entry;

public interface EntryDao {
    @NonNull
    OperationResult<UUID> insert(@NonNull Entry note);

    @NonNull
    OperationResult<Boolean> remove(@NonNull UUID noteUid);
}
