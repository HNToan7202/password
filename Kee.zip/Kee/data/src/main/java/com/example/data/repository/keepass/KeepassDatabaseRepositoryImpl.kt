package com.example.data.repository.keepass

import android.content.Context
import app.keemobile.kotpass.database.Credentials
import app.keemobile.kotpass.database.KeePassDatabase
import app.keemobile.kotpass.database.modifiers.removeEntry
import app.keemobile.kotpass.models.Entry
import com.example.data.entity.FileDescriptor
import com.example.data.extension.mapError
import com.example.data.file.FSOptions
import com.example.data.result.OperationResult
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import javax.inject.Inject

class KeepassDatabaseRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : KeepassDatabaseRepository {

    private var database: AtomicReference<KotpassDatabase?>? = null

    override suspend fun createNewDatabase(
        credentials: Credentials,
        fsOptions: FSOptions,
        file: FileDescriptor,
    ): OperationResult<KeePassDatabase> {
        return KotpassDatabase.new(context, credentials, fsOptions, file)
    }

    override fun setDatabase(db: KeePassDatabase, fsOptions: FSOptions, dbFile: FileDescriptor) {
        val kotpassDatabase = KotpassDatabase(
            context = context,
            fsOptions = fsOptions,
            file = dbFile,
            db = db
        )
        database = AtomicReference(kotpassDatabase)
    }

    override fun getDatabase(): KeePassDatabase? = database?.get()?.getRawDatabase()

    override fun getAllEntries(): List<Entry> {
        return getDatabase()?.content?.group?.entries.orEmpty()
    }

    override fun isOpened(): Boolean = (database?.get() != null)

    override fun getRootEntryById(id: UUID): Flow<Entry?> = flow {
        val entries = getDatabase()?.content?.group?.entries ?: emptyList()
        emit(entries.find { it.uuid == id })
    }


    override fun getRootGroupId(): UUID? {
        return getDatabase()?.content?.group?.uuid
    }

    override suspend fun addEntryToGroup(entry: Entry): OperationResult<UUID?> {
        val result = database?.get()?.getEntryDao()?.insert(entry)

        if (result != null && result.isSucceeded) {
            return OperationResult.success<UUID>(result.obj)
        }
        return OperationResult.error<UUID>(null).mapError()
    }

    override fun removeEntry(entryId: UUID): OperationResult<Boolean> {
        val result = database?.get()?.removeEntry(entryId)
        return if (result != null && result.isSucceeded) {
            result
        } else {
            OperationResult<Boolean>().mapError()
        }
    }
}