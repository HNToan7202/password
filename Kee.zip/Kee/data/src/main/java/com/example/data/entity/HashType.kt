package com.example.data.entity

enum class HashType {
    SHA_256
}