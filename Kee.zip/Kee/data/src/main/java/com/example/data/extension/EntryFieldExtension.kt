package com.example.data.extension

import app.keemobile.kotpass.cryptography.EncryptedValue
import app.keemobile.kotpass.models.EntryFields
import app.keemobile.kotpass.models.EntryValue
import com.example.data.entity.Property
import kotlin.collections.component1
import kotlin.collections.component2
import kotlin.collections.map

fun EntryFields.toProperties(): List<Property> {
    return this.map { (key, entryValue) ->
        val isProtected = entryValue is EntryValue.Encrypted
        val value = when (entryValue) {
            is EntryValue.Plain -> entryValue.content
            is EntryValue.Encrypted -> null
        }

        Property(
            name = key,
            value = value,
            isProtected = isProtected
        )
    }
}

fun List<Property>.toEntryFields(): EntryFields {
    return EntryFields.of(*this.map {
        val entryValue = if (it.isProtected && it.value != null) {
            EntryValue.Encrypted(EncryptedValue.fromString(it.value))
        } else {
            EntryValue.Plain(it.value ?: "")
        }
        it.name!! to entryValue
    }.toTypedArray())
}