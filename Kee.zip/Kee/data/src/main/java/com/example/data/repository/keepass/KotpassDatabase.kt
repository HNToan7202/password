package com.example.data.repository.keepass

import android.content.Context
import app.keemobile.kotpass.constants.BasicField
import app.keemobile.kotpass.database.Credentials
import app.keemobile.kotpass.database.KeePassDatabase
import app.keemobile.kotpass.database.encode
import app.keemobile.kotpass.database.modifiers.modifyMeta
import app.keemobile.kotpass.models.Entry
import app.keemobile.kotpass.models.EntryFields
import app.keemobile.kotpass.models.EntryValue
import app.keemobile.kotpass.models.Group
import app.keemobile.kotpass.models.Meta
import com.example.data.entity.FSAuthority.Companion.INTERNAL_FS_AUTHORITY
import com.example.data.entity.FileDescriptor
import com.example.data.extension.encdb.EncryptedDatabaseConfig
import com.example.data.extension.encdb.MutableEncryptedDatabaseConfig
import com.example.data.extension.getOrNull
import com.example.data.extension.mapError
import com.example.data.file.FSOptions
import com.example.data.file.OnConflictStrategy
import com.example.data.file.Regular.RegularFileSystemProvider
import com.example.data.result.OperationError.GENERIC_MESSAGE_FAILED_TO_FIND_ENTITY_BY_UID
import com.example.data.result.OperationError.MESSAGE_FAILED_TO_FIND_GROUP
import com.example.data.result.OperationError.MESSAGE_WRITE_OPERATION_IS_NOT_SUPPORTED
import com.example.data.result.OperationError.newDbError
import com.example.data.result.OperationError.newGenericIOError
import com.example.data.result.OperationResult
import com.example.data.result.Stacktrace
import com.example.data.utils.InputOutputUtils
import kotlinx.coroutines.sync.Mutex
import timber.log.Timber
import java.io.IOException
import java.util.LinkedList
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference

class KotpassDatabase(
    private val context: Context,
    private val fsOptions: FSOptions,
    file: FileDescriptor,
    db: KeePassDatabase
) {

    private val database = AtomicReference(db)

    fun getRawDatabase(): KeePassDatabase = database.get()

    private val file = AtomicReference(file)

    private val entryDao = KotpassEntryDao(this)

    fun getRawRootGroup(): Group = database.get().content.group

    private val lock = Mutex()

    fun getConfig(): OperationResult<EncryptedDatabaseConfig> {
        val rawDatabase = getRawDatabase()

        val config = MutableEncryptedDatabaseConfig(
            isRecycleBinEnabled = rawDatabase.content.meta.recycleBinEnabled,
            maxHistoryItems = rawDatabase.content.meta.historyMaxItems
        )

        return OperationResult.success(config)
    }

    companion object {

        const val DEFAULT_ROOT_INHERITABLE_VALUE = true

        private const val DEFAULT_ROOT_GROUP_NAME = "Database"

        fun new(
            context: Context,
            credentials: Credentials,
            fsOptions: FSOptions,
            file: FileDescriptor,
        ): OperationResult<KeePassDatabase> {

            val rawDb = KeePassDatabase.Ver4x.create(
                rootName = DEFAULT_ROOT_GROUP_NAME,
                meta = Meta(
                    recycleBinEnabled = true
                ),
                credentials = credentials
            )

            val rootGroupUId = rawDb.content.group.uuid

            val newEntry = Entry(
                uuid = UUID.randomUUID(),
                overrideUrl = "12345",
                fields = EntryFields.of(
                    BasicField.Title() to EntryValue.Plain("This is default entry"),
                    BasicField.Password() to EntryValue.Plain("default password entry"),
                    BasicField.UserName() to EntryValue.Plain("default username entry"),
                ),
                previousParentGroup = rootGroupUId,
            )

            val oldGroup = rawDb.content.group
            val updatedGroup = oldGroup.copy(entries = oldGroup.entries + newEntry)

            val updatedDb = rawDb.copy(content = rawDb.content.copy(group = updatedGroup))

            val finalDb = updatedDb.modifyMeta {
                copy(
                    recycleBinEnabled = true,
                    recycleBinUuid = UUID.randomUUID(),
                    entryTemplatesGroup = entryTemplatesGroup
                )
            }

            val database = AtomicReference(finalDb)

            val updatedFile = file.copy(modified = System.currentTimeMillis())

            val fsProvider = RegularFileSystemProvider(context, INTERNAL_FS_AUTHORITY)

            val outResult = fsProvider.openFileForWrite(
                updatedFile,
                OnConflictStrategy.CANCEL,
                fsOptions
            )

            if (outResult.isFailed) {
                Timber.e("Kotpass: Failed to open file: ${outResult.error?.message}")

                return OperationResult.error(
                    newGenericIOError(
                        MESSAGE_WRITE_OPERATION_IS_NOT_SUPPORTED,
                        Stacktrace()
                    )
                )
            }

            val out = outResult.obj!!
            database.get().encode(out)
            Timber.d("Kotpass: Database written successfully: ${updatedFile.path}")

            return OperationResult.success(finalDb)

        }

    }

    fun isEntryInsideGroupTree(
        entryUid: UUID,
        groupTreeRootUid: UUID
    ): OperationResult<Boolean> {
        val getTreeRootResult = getRawGroupByUid(groupTreeRootUid)
        if (getTreeRootResult.isFailed) {
            return getTreeRootResult.mapError()
        }

        val rawTreeRoot = getTreeRootResult.obj
        val tree = getRawChildEntries(rawTreeRoot)

        val isEntryInsideTree = tree.any { entry -> entry.uuid == entryUid }

        return OperationResult.success(isEntryInsideTree)
    }

    fun getRawChildEntries(root: Group): List<Entry> {
        val nextGroups = LinkedList<Group>()
            .apply {
                add(root)
            }

        val allEntries = mutableListOf<Entry>()

        while (nextGroups.isNotEmpty()) {
            val currentGroup = nextGroups.pop()
            nextGroups.addAll(currentGroup.groups)
            allEntries.addAll(currentGroup.entries)
        }

        return allEntries
    }


    fun getRecycleBinGroup(): OperationResult<Group?> {
        val rawDb = getRawDatabase()

        val isRecycleBinEnabled = rawDb.content.meta.recycleBinEnabled
        if (!isRecycleBinEnabled) {
            return OperationResult.success(null)
        }

        val recycleBinUid = rawDb.content.meta.recycleBinUuid
            ?: return OperationResult.success(null)

        val getRecycleBinResult = getRawGroupByUid(recycleBinUid)
        return OperationResult.success(getRecycleBinResult.getOrNull())
    }


    fun getRawGroupByUid(uid: UUID): OperationResult<Group> {
        val rootGroup = database.get().content.group
        if (rootGroup.uuid == uid) {
            return OperationResult.success(rootGroup)
        }

        val (_, parentGroup) = rootGroup.findChildGroup { it.uuid == uid }
            ?: return OperationResult.error(
                newDbError(
                    MESSAGE_FAILED_TO_FIND_GROUP,
                    Stacktrace()
                )
            )

        return OperationResult.success(parentGroup)
    }

    fun swapDatabase(db: KeePassDatabase) {
        database.set(db)
    }

    fun commit(): OperationResult<Boolean> {
        val updatedFile = file.get().copy(modified = System.currentTimeMillis())

        val result = commitTo(updatedFile, fsOptions)
        if (result.isSucceededOrDeferred) {
            file.set(updatedFile)
        }

        return result
    }

    fun commitTo(
        output: FileDescriptor,
        fsOptions: FSOptions
    ): OperationResult<Boolean> {
        val fsProvider = RegularFileSystemProvider(context, INTERNAL_FS_AUTHORITY)

        val outResult = fsProvider.openFileForWrite(
            output,
            OnConflictStrategy.CANCEL,
            fsOptions
        )
        if (outResult.isFailed) {
            return outResult.mapError()
        }

        val out = outResult.obj
        val db = database.get()
        try {
            db.encode(out)
            outResult.takeStatusWith(true)
        } catch (e: IOException) {
            InputOutputUtils.close(out)
            OperationResult.error(newGenericIOError(e))
        }
        return OperationResult.success(true)
    }

    fun getEntryDao() = entryDao

    fun getRawEntryAndGroupByUid(noteUid: UUID): OperationResult<Pair<Group, Entry>> {
        val result = database.get().content.group.findChildEntry { entry ->
            entry.uuid == noteUid
        }
            ?: return OperationResult.error(
                newDbError(
                    String.format(
                        GENERIC_MESSAGE_FAILED_TO_FIND_ENTITY_BY_UID,
                        Entry::class.simpleName,
                        noteUid
                    ),
                    Stacktrace()
                )
            )
        return OperationResult.success(result)
    }

    fun removeEntry(entryId: UUID): OperationResult<Boolean> {
        return entryDao.remove(entryId)
    }
}