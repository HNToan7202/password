package com.example.data.file

import android.content.Context
import com.example.data.entity.FSAuthority
import com.example.data.entity.FSType
import java.nio.file.spi.FileSystemProvider
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

open class FileSystemResolver(
    protected open val factories: Map<FSType, Factory>
) {

    private val providers: MutableMap<FSAuthority, FileSystemProvider> = HashMap()
    private val lock = ReentrantLock()

    fun getAvailableFsTypes(): Set<FSType> {
        return factories.keys
    }

    fun resolveProvider(fsAuthority: FSAuthority): FileSystemProvider {
        var result: FileSystemProvider

        lock.withLock {
            val provider = providers[fsAuthority]
            if (provider == null) {
                result = instantiateProvider(fsAuthority).also {
                    providers[fsAuthority] = it
                }
            } else {
                result = provider
            }
        }

        return result
    }


    private fun instantiateProvider(fsAuthority: FSAuthority): FileSystemProvider {
        val factory = factories[fsAuthority.type]
            ?: throw IllegalStateException("No factory for type: ${fsAuthority.type}")

        return factory.createProvider(fsAuthority)
    }

    companion object {

//        fun buildFactories(
//            context: Context,
//            isExternalStorageAccessEnabled: Boolean
//        ): Map<FSType, Factory> {
//            val result = mutableMapOf(
//                FSType.INTERNAL_STORAGE to InternalFileSystemFactory(),
//                FSType.SAF to SAFFileSystemFactory(),
//            )
//
//            if (isExternalStorageAccessEnabled) {
//                result[FSType.EXTERNAL_STORAGE] = ExternalFileSystemFactory()
//            }
//
//            return result
//        }
    }

    fun interface Factory {
        fun createProvider(fsAuthority: FSAuthority): FileSystemProvider
    }

//    class InternalFileSystemFactory(context: Context) : Factory {
//        override fun createProvider(fsAuthority: FSAuthority): FileSystemProvider {
//            return RegularFileSystemProvider(context, FSAuthority.INTERNAL_FS_AUTHORITY)
//        }
//    }

//    class ExternalFileSystemFactory : Factory {
//        override fun createProvider(fsAuthority: FSAuthority): FileSystemProvider {
//            return RegularFileSystemProvider(get(), FSAuthority.EXTERNAL_FS_AUTHORITY)
//        }
//    }

//    class SAFFileSystemFactory : Factory {
//        override fun createProvider(fsAuthority: FSAuthority): FileSystemProvider {
//            return SAFFileSystemProvider(get(), get())
//        }
//    }
}